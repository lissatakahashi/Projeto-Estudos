import type { Config } from 'tailwindcss';
import plugin from 'tailwindcss/plugin';

const config: Config = {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{ts,tsx,js,jsx}'],
  theme: {
    container: {
      center: true,
      padding: {
        DEFAULT: '1rem',
        sm: '1.5rem',
        lg: '2rem',
      },
      screens: {
        lg: '1120px',
      },
    },
    extend: {
      fontFamily: {
        display: ['Inter', 'ui-sans-serif', 'system-ui'],
        text: ['Inter', 'ui-sans-serif', 'system-ui'],
      },
      fontSize: {
        base: ['15px', { lineHeight: '1.6' }],
      },
      colors: {
        // Explicit theme colors for the project
        brand: {
          600: '#0e7490',
          700: '#0c596e',
          800: '#0a4454',
        },
        'brand-contrast': '#ffffff',
        ink: '#111827',
        muted: '#6b7280',
        surface: '#ffffff',
        cardLight: '#f9fafb',
        cardDark: '#0f172a',
      },
      borderRadius: {
        lg: '1rem',
      },
      spacing: {
        'container-y-sm': '24px',
      },
    },
  },
  plugins: [
    plugin(function ({ addComponents, addUtilities, theme }) {
      // Add ready-made component classes so consumers can simply use
      // <section class="section"> or <div class="card"> without
      // relying on @apply variants that the dev plugin may reject.
      addComponents({
        '.section': {
          paddingTop: theme('spacing.16'),
          paddingBottom: theme('spacing.16'),
          '@media (min-width: 768px)': {
            paddingTop: theme('spacing.20'),
            paddingBottom: theme('spacing.20'),
          },
        },
        '.wrapper': {
          maxWidth: '1120px',
          marginLeft: 'auto',
          marginRight: 'auto',
          paddingLeft: theme('spacing.4'),
          paddingRight: theme('spacing.4'),
          '@media (min-width: 640px)': {
            paddingLeft: theme('spacing.6'),
            paddingRight: theme('spacing.6'),
          },
          '@media (min-width: 1024px)': {
            paddingLeft: theme('spacing.8'),
            paddingRight: theme('spacing.8'),
          },
        },
        '.card': {
          borderRadius: theme('borderRadius.2xl'),
          boxShadow: theme('boxShadow.sm'),
          transition: 'box-shadow 160ms ease',
          backgroundColor: 'rgba(255,255,255,0.9)',
        },
        '.card:hover': {
          boxShadow: theme('boxShadow.md') || '0 8px 24px rgba(2,6,23,0.08)',
        },
        '.dark .card': {
          backgroundColor: 'rgba(15,23,42,0.9)',
        },
      });
      // Add small helper utilities used by src/styles/index.css when using @apply
      addUtilities(
        {
          '.max-w-1120': { maxWidth: '1120px' },
          '.bg-card-dark-90': { backgroundColor: 'rgba(15,23,42,0.9)' },
        },
        {
          variants: ['responsive', 'hover', 'dark'],
        }
      );
    }),
  ],
};

export default config;
