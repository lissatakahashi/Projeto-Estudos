import React from 'react';
const year = new Date().getFullYear();

const Footer: React.FC = () => (
  <section className="bg-surface dark:bg-card border-t">
    <div className="wrapper grid grid-cols-2 md:grid-cols-4 gap-6 text-sm">
      <div>
        <h4 className="font-semibold mb-2">Produto</h4>
        <nav aria-label="Produto">
          <a href="/pomodoro" className="block py-1">Pomodoro</a>
          <a href="/shop" className="block py-1">Loja</a>
          <a href="/inventory" className="block py-1">Inventário</a>
        </nav>
      </div>

      <div>
        <h4 className="font-semibold mb-2">Recursos</h4>
        <nav aria-label="Recursos">
          <a href="/history" className="block py-1">Histórico</a>
          <a href="/badges" className="block py-1">Badges</a>
        </nav>
      </div>

      <div>
        <h4 className="font-semibold mb-2">Institucional</h4>
        <nav aria-label="Institucional">
          <a href="/about" className="block py-1">Sobre</a>
          <a href="/method" className="block py-1">Metodologia</a>
        </nav>
      </div>

      <div>
        <h4 className="font-semibold mb-2">Legal</h4>
        <nav aria-label="Legal">
          <a href="/privacy" className="block py-1">Privacidade</a>
          <a href="/terms" className="block py-1">Termos</a>
        </nav>
      </div>
    </div>
    <div className="border-t py-4 text-xs text-muted">
      <div className="wrapper flex items-center justify-between">
        <div>© {year} tcc-prototype</div>
        <div>Todos os direitos reservados</div>
      </div>
    </div>
  </section>
);

export default Footer;
