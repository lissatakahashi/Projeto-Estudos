import React from 'react';
import { Link } from 'react-router-dom';
import ThemeToggle from './ThemeToggle';
import { Sheet, SheetContent, SheetTrigger } from '../ui/Sheet';

const navLinks = [
  { to: '/pomodoro', label: 'Pomodoro' },
  { to: '/shop', label: 'Loja' },
  { to: '/inventory', label: 'Inventário' },
  { to: '/history', label: 'Histórico' },
  { to: '/about', label: 'Sobre' },
];

const Navbar: React.FC = () => {
  const [open, setOpen] = React.useState(false);

  return (
    <nav className="border-b border-black/5 dark:border-white/5 bg-surface/80 backdrop-blur supports-[backdrop-filter]:bg-surface/60 sticky top-0 z-50">
      <div className="wrapper grid grid-cols-[1fr_auto_1fr] items-center h-14 px-4 md:px-6 lg:px-8">
        {/* Coluna 1: Brand */}
        <Link to="/" className="font-semibold tracking-tight">
          tcc-prototype
        </Link>

        {/* Coluna 2: Links (md+) */}
        <ul className="hidden md:flex items-center gap-6 text-sm text-muted justify-center">
          {navLinks.map((link) => (
            <li key={link.to}>
              <Link to={link.to} className="hover:text-foreground transition-colors">
                {link.label}
              </Link>
            </li>
          ))}
        </ul>

        {/* Coluna 3: ThemeToggle e CTA */}
        <div className="flex items-center justify-end gap-2">
          <ThemeToggle />
          <Link to="/pomodoro" className="btn btn-primary">
            Começar
          </Link>

          {/* Mobile: Hamburger button */}
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <button
                className="md:hidden p-2 rounded focus:outline-none"
                aria-label="Abrir menu"
                aria-expanded={open}
                aria-controls="mobile-navigation"
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden>
                  <path d="M4 6h16M4 12h16M4 18h16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </button>
            </SheetTrigger>
            <SheetContent>
              <div id="mobile-navigation" className="flex flex-col gap-4 mt-4">
                {navLinks.map((link) => (
                  <Link
                    key={link.to}
                    to={link.to}
                    className="text-sm hover:text-foreground transition-colors"
                    onClick={() => setOpen(false)}
                  >
                    {link.label}
                  </Link>
                ))}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
