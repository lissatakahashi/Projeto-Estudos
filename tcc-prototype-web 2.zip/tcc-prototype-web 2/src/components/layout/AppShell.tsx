import React from 'react';
import Navbar from './Navbar';
import Footer from './Footer';

const AppShell: React.FC<{ children?: React.ReactNode }> = ({ children }) => (
  <div className="min-h-screen flex flex-col">
    <a href="#conteudo-principal" className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:z-50 focus:px-4 focus:py-2 focus:bg-surface focus:text-ink focus:border focus:rounded">Pular para o conteúdo principal</a>
    <Navbar />
    <main id="conteudo-principal" className="flex-1 container mx-auto px-4 py-8">
      {children}
    </main>
    <Footer />
  </div>
);

export default AppShell;
