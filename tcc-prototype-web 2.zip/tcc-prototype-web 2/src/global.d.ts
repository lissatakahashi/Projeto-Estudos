declare module '*.png';
declare module '*.jpg';
declare module '*.svg';
declare module '*.css';

declare module 'react/jsx-runtime';
