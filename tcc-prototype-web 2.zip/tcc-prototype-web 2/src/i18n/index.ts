import messagesPt from './messages.pt-BR.json';

export const messages = {
  'pt-BR': messagesPt,
};

export const defaultLocale = 'pt-BR';
