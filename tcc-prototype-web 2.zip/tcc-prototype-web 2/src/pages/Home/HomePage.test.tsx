import { render, screen } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import { BrowserRouter } from 'react-router-dom';
import HomePage from './HomePage';

describe('HomePage', () => {
  it('renders H1, finds 2 CTAs in Hero, 3 benefit cards and CookieBanner', () => {
    render(
      <BrowserRouter>
        <HomePage />
      </BrowserRouter>,
    );
    expect(screen.getByRole('heading', { level: 1, name: /Foco com Pomodoro/i })).toBeTruthy();
    const heroLinks = screen.getAllByRole('link');
    expect(heroLinks.length).toBeGreaterThanOrEqual(2); // At least 2 CTAs in Hero
    expect(screen.getAllByRole('heading', { level: 3, name: /Foco|Recompensas|Progresso/i })).toHaveLength(3); // 3 benefit cards
    expect(screen.getByText(/Usamos armazenamento local/i)).toBeTruthy();
  });
});

