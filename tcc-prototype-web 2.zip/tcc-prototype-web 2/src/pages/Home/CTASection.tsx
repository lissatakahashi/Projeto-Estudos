import React from 'react';
import { Link } from 'react-router-dom';

const CTASection: React.FC = () => (
  <section className="section">
    <div className="wrapper">
      <div className="bg-brand-600 text-brand-contrast rounded-2xl p-8 text-center space-y-4">
        <h3 className="text-2xl font-semibold">Pronto para começar?</h3>
        <p className="text-sm text-brand-contrast/90">Inicie seu primeiro Pomodoro e comece a evoluir hoje.</p>
        <Link to="/pomodoro" className="btn">Iniciar Pomodoro</Link>
      </div>
    </div>
  </section>
);

export default CTASection;
