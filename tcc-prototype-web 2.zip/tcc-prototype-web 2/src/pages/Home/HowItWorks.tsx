import React from 'react';
import { motion } from '../../lib/motion';
import { CheckCircle, Gift, Settings, Clock } from '../../lib/icons';

const steps = [
  { icon: <Clock />, title: 'Pomodoro', text: 'Ciclos de foco e pausas.' },
  { icon: <Gift />, title: 'Recompensa', text: 'Ganhe pontos ao completar sessões.' },
  { icon: <Settings />, title: 'Personalize', text: 'Ajuste timers e recompensas.' },
  { icon: <CheckCircle />, title: 'Revise', text: 'Analise seu progresso e melhore.' },
];

const HowItWorks: React.FC = () => (
  <section className="section">
    <div className="wrapper">
      <h2 className="text-2xl font-semibold mb-6">Como funciona</h2>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 md:gap-8 md:border-t md:border-dashed md:border-muted/40 md:pt-6">
        {steps.map((s, i) => (
          <motion.div
            key={s.title}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.06 }}
            className="flex flex-col items-start"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className="bg-muted text-muted-foreground text-xs font-medium px-2 py-1 rounded-full">{i + 1}</div>
              <div className="text-brand-600">{s.icon}</div>
            </div>
            <h4 className="font-semibold mb-1">{s.title}</h4>
            <p className="text-sm text-muted">{s.text}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default HowItWorks;
