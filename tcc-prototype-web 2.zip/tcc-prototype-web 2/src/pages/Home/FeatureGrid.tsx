import React from 'react';
import Card from '../../components/ui/Card';
import { Target, Trophy, BarChart3 } from '../../lib/icons';
import { motion } from '../../lib/motion';

const features = [
  { icon: <Target />, title: 'Foco concentrado', text: 'Ciclos Pomodoro com metas claras para máxima produtividade.' },
  { icon: <Trophy />, title: 'Recompensas', text: 'Gamifique seu progresso com conquistas e badges motivadores.' },
  { icon: <BarChart3 />, title: 'Progresso', text: 'Visualize métricas e evolução ao longo do tempo.' },
];

const FeatureGrid: React.FC = () => (
  <section className="section bg-[color:var(--card,theme(colors.cardLight))] dark:bg-cardDark/60">
    <div className="wrapper">
      <h2 className="text-sm font-semibold tracking-wider text-muted uppercase">Benefícios</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
        {features.map((f, i) => (
          <motion.div key={f.title} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }}>
            <Card className="p-6">
              <div className="flex items-start gap-4">
                <div className="text-brand-600 text-2xl mt-1" aria-hidden>{f.icon}</div>
                <div>
                  <h3 className="font-semibold text-ink">{f.title}</h3>
                  <p className="text-sm text-muted mt-1">{f.text}</p>
                </div>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default FeatureGrid;
