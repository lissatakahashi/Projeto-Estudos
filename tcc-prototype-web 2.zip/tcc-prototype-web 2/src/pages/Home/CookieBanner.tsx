import React from 'react';
import { Link } from 'react-router-dom';

const CookieBanner: React.FC = () => {
  const storageKey = 'privacyConsent';
  const [accepted, setAccepted] = React.useState<boolean>(() =>
    typeof window !== 'undefined' && localStorage.getItem(storageKey) === 'true'
  );

  const accept = () => {
    try {
      localStorage.setItem(storageKey, 'true');
    } catch (e) {
      // ignore localStorage failures
    }
    setAccepted(true);
  };

  if (accepted) return null;

  return (
    <div
      role="dialog"
      aria-label="Consentimento de privacidade"
      className="fixed bottom-4 left-1/2 -translate-x-1/2 w-[min(92vw,960px)] bg-surface dark:bg-card border p-4 rounded-lg shadow-lg"
    >
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="text-sm">Usamos armazenamento local para preferências e progresso. Sem backend neste protótipo.</div>
        <div className="flex items-center gap-2">
          <button onClick={accept} className="btn">Aceitar</button>
          <Link to="/privacy" className="text-sm underline">Saiba mais</Link>
        </div>
      </div>
    </div>
  );
};

export default CookieBanner;
