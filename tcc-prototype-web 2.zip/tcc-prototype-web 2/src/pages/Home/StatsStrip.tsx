import React from 'react';

const StatsStrip: React.FC = () => (
  <section className="py-8">
    <div className="bg-card rounded-2xl p-6 flex flex-col md:flex-row items-center justify-between gap-4">
      <div className="text-center">
        <div className="text-3xl font-bold">12.4k</div>
        <div className="text-sm text-muted">Sessões concluídas</div>
      </div>
      <div className="text-center">
        <div className="text-3xl font-bold">1,234h</div>
        <div className="text-sm text-muted">Tempo focado</div>
      </div>
      <div className="text-center">
        <div className="text-3xl font-bold">45</div>
        <div className="text-sm text-muted">Maior streak</div>
      </div>
    </div>
  </section>
);

export default StatsStrip;
