import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import Router from './app/router';
import './styles/index.css';

if (process.env.NODE_ENV === 'development') {
  import('@axe-core/react').then(({ default: ReactAxe }) => {
    ReactAxe(React, createRoot(document.getElementById('root')!), 1000);
  });
}

function App() {
  return (
    <BrowserRouter>
      <Router />
    </BrowserRouter>
  );
}

createRoot(document.getElementById('root')!).render(<App />);
