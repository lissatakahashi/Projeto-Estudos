export const completePomodoro = () => {
  console.log('completePomodoro called');
};
