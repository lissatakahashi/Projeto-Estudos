export const penalizeLostFocus = () => {
  console.log('penalizeLostFocus called');
};
