export const startPomodoro = () => {
  // placeholder: iniciar pomodoro
  console.log('startPomodoro called');
};
