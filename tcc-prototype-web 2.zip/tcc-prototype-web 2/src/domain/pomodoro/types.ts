export type Pomodoro = {
  id: string;
  duration: number;
  completed: boolean;
};
