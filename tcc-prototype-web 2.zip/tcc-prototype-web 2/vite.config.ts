import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Use an async config and dynamic import for the Tailwind Vite plugin because
// the plugin is ESM-only; dynamic import avoids `require`-based loading issues
// during esbuild's config resolution in some environments.
export default defineConfig(async () => {
  const plugins: any[] = [react()];

  // Only load the Tailwind Vite plugin during dev/build time. In production
  // (e.g. when running `vite preview` inside the runner image) the built
  // assets are already present and we avoid importing the ESM-only plugin.
  if (process.env.NODE_ENV !== 'production') {
    const tailwind = (await import('@tailwindcss/vite')).default;
    plugins.push(tailwind());
  }

  return { plugins, server: { port: 5173 } };
});
