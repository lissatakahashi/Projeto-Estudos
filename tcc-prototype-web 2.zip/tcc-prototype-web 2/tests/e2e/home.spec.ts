// Playwright e2e test (kept separate so Vitest doesn't pick it up)
import { test, expect } from '@playwright/test';

test('home smoke', async ({ page }) => {
  await page.goto('http://localhost:5174/');
  await expect(page.getByText('Foco com Pomodoro')).toBeVisible();
  await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
  await page.locator('text=Aceitar').click();
  await page.locator('text=Começar agora').click();
  await expect(page).toHaveURL(/\/pomodoro/);
  await page.goBack();
  await page.locator('button[aria-label="Abrir menu"]').click();
  await page.locator('text=Sobre').click();
  await expect(page).toHaveURL(/\/about/);
});

