// Keep PostCSS config minimal for the build. Tailwind integration is handled via
// the Vite plugin `@tailwindcss/vite` (preferred for Tailwind v4+). Only add
// autoprefixer here so PostCSS still runs.
module.exports = { plugins: { autoprefixer: {} } };
